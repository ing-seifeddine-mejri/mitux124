### Expected behavior and actual behavior.

### Steps to reproduce the problem.

### What version of opencats are you running? 

#### Release or downloaded from Git? 

#### WAMP or LAMP? 

### What version of PHP and MySQL are you running

### attach appropriate error logs. Please attach [apache/mysql] error/access logs as needed.
